<?php
include "corefile.php";

$print = getPwdInfo("69133548962772803292499301221450", "github.com");
printJSON($print);