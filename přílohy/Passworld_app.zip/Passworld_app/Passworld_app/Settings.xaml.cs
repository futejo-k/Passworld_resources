﻿using System.Windows;
using System.Windows.Controls;

namespace Passworld_app;

public partial class Settings : Window
{
    public Settings()
    {
        InitializeComponent();
    }

    private void Back_OnClick(object sender, RoutedEventArgs e)
    {
        this.Hide();
        (new Homepage()).Show();
        this.Close();
    }

    private void ChangeInfo_OnClick(object sender, RoutedEventArgs e)
    {
        
    }
}